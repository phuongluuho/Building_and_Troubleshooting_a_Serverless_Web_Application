default_app_config = 'aws_xray_sdk.ext.django.apps.XRayConfig'
